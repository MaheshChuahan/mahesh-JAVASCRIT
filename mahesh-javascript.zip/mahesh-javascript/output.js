// console 
console.log("mahesh chauhan")
// alert 
alert("Hello world")
// document.write 
document.write("how are you?")
// Dom => id 
document.getElementById('para').textContent;